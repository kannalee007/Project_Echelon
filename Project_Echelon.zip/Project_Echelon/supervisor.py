#!/usr/bin/env python3
"""
Project Echelon - Supervisor (Swarm Entry Point)
LangGraph multi-agent swarm orchestrator for autonomous trading decisions.
"""

import json
from typing import TypedDict
from confluent_kafka import Consumer, KafkaError
from rich.console import Console
from rich.panel import Panel
from langgraph.graph import StateGraph, START, END
from langchain_ollama import OllamaLLM

console = Console()

# Configuration
BROKER = "localhost:19092"
TOPIC = "market_live_feed"
GROUP_ID = "echelon-swarm"

# Initialize Ollama LLM
llm = OllamaLLM(model="qwen2.5:7b")

# ============================================================================
# Agent State Definition
# ============================================================================

class AgentState(TypedDict):
    market_data: dict
    research_context: str
    quant_analysis: str
    risk_analysis: str
    final_decision: str

# ============================================================================
# Researcher Agent Node (NEW)
# ============================================================================

def researcher_node(state: AgentState) -> AgentState:
    """
    Research Agent
    Simulates web/GraphRAG search to gather contextual intelligence on the ticker.
    """
    data = state["market_data"]
    ticker = data.get("ticker", "UNKNOWN")
    
    # Hardcoded contextual intelligence based on ticker
    research_db = {
        "AAPL": "Supply chain rumors in Taiwan; potential iPhone production delays reported",
        "NVDA": "New H100 chip demand exceeding supply; Blackwell architecture rumors",
        "TSLA": "Cybertruck production scaling issues; FSD v12 beta showing mixed results",
        "MSFT": "Azure growth slowing QoQ; Copilot enterprise adoption strong",
        "GOOGL": "DOJ antitrust trial phase 2 beginning; Search market share stable",
        "AMZN": "AWS revenue up 14% this quarter; logistics network optimization ongoing",
        "META": "Threads DAU declining; VR headset sales below expectations",
        "BTC-USD": "ETF inflows accelerating; halving event approaching in 12 months",
        "ETH-USD": "Layer 2 adoption surging; staking yields competitive vs traditional"
    }
    
    context = research_db.get(ticker, "No major breaking news; market conditions normal")
    state["research_context"] = context
    return state

# ============================================================================
# Agent Nodes
# ============================================================================

def quant_node(state: AgentState) -> AgentState:
    """
    Quantitative Analyst Agent
    Analyzes price and volume momentum, incorporating research context.
    """
    data = state["market_data"]
    research = state.get("research_context", "No research available")
    ticker = data.get("ticker", "UNKNOWN")
    price = data.get("current_price", 0)
    volume = data.get("volume", 0)
    
    prompt = f"""You are a Quantitative Analyst. Analyze this market data:
Ticker: {ticker}
Current Price: ${price}
Volume: {volume}

You have access to the following research intelligence:
RESEARCH CONTEXT: {research}

Provide a 2-sentence analysis on whether to Buy, Sell, or Hold based on price/volume momentum AND the research context. Be concise and direct."""

    analysis = llm.invoke(prompt)
    state["quant_analysis"] = analysis.strip()
    return state

def risk_node(state: AgentState) -> AgentState:
    """
    Risk Manager Agent
    Evaluates market volatility and research context to assess trading danger.
    """
    data = state["market_data"]
    research = state.get("research_context", "No research available")
    volatility = data.get("volatility_index", 0)
    
    prompt = f"""You are a Risk Manager. The current market volatility index is {volatility}.

You have access to the following research intelligence:
RESEARCH CONTEXT: {research}

Provide a 2-sentence analysis on whether the market is too dangerous to trade right now, considering BOTH volatility AND the research context. Be concise."""

    analysis = llm.invoke(prompt)
    state["risk_analysis"] = analysis.strip()
    return state

def ceo_node(state: AgentState) -> AgentState:
    """
    Executive Director Agent
    Resolves the debate between Quant and Risk Manager, incorporating research.
    """
    quant = state.get("quant_analysis", "No quant analysis")
    risk = state.get("risk_analysis", "No risk analysis")
    research = state.get("research_context", "No research available")
    
    prompt = f"""You are the Executive Director of a hedge fund. You have received three inputs:

RESEARCH INTELLIGENCE: {research}

QUANTITATIVE ANALYSIS: {quant}

RISK MANAGEMENT ANALYSIS: {risk}

As the final decision maker, resolve this debate and output a definitive, single action.
Your response must start with one of: "EXECUTE BUY", "EXECUTE SELL", or "HOLD POSITION"
Followed by a brief 1-sentence justification that references the research context. Be authoritative and decisive."""

    decision = llm.invoke(prompt)
    state["final_decision"] = decision.strip()
    return state

# ============================================================================
# Build the LangGraph
# ============================================================================

def build_swarm_graph():
    """Construct the multi-agent swarm graph with research node."""
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("researcher_node", researcher_node)
    workflow.add_node("quant_node", quant_node)
    workflow.add_node("risk_node", risk_node)
    workflow.add_node("ceo_node", ceo_node)
    
    # Define flow: START -> researcher -> quant -> risk -> ceo -> END
    workflow.add_edge(START, "researcher_node")
    workflow.add_edge("researcher_node", "quant_node")
    workflow.add_edge("quant_node", "risk_node")
    workflow.add_edge("risk_node", "ceo_node")
    workflow.add_edge("ceo_node", END)
    
    return workflow.compile()

# Compile the graph once at module level
swarm_graph = build_swarm_graph()

# ============================================================================
# Main Consumer Loop
# ============================================================================

def main():
    conf = {
        "bootstrap.servers": BROKER,
        "group.id": GROUP_ID,
        "auto.offset.reset": "latest",
        "enable.auto.commit": True
    }
    
    consumer = Consumer(conf)
    consumer.subscribe([TOPIC])
    
    console.print(Panel.fit(
        "[bold cyan]Project Echelon - Swarm Supervisor[/bold cyan]\n"
        f"Broker: {BROKER}\n"
        f"Topic: {TOPIC}\n"
        f"Group: {GROUP_ID}\n"
        f"LLM: qwen2.5:7b\n"
        f"Features: Research Context + Multi-Agent Debate\n\n"
        "[dim]Waiting for market data...[/dim]",
        title="Initializing",
        border_style="cyan"
    ))
    
    try:
        while True:
            msg = consumer.poll(timeout=1.0)
            
            if msg is None:
                continue
            
            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    continue
                else:
                    console.print(f"[red]Consumer error: {msg.error()}[/red]")
                    break
            
            try:
                data = json.loads(msg.value().decode("utf-8"))
                volatility = data.get("volatility_index", 0)
                ticker = data.get("ticker", "UNKNOWN")
                
                console.print(
                    f"[bold cyan][SWARM INGESTING][/bold cyan] {ticker} | "
                    f"Price: ${data.get('current_price')} | "
                    f"Volatility: {volatility}"
                )
                
                # Threshold trigger: Only invoke graph if volatility > 4.0
                if volatility > 4.0:
                    console.print("[yellow]High volatility detected! Activating AI swarm with research context...[/yellow]")
                    
                    # Initialize state and execute swarm
                    initial_state: AgentState = {
                        "market_data": data,
                        "research_context": "",
                        "quant_analysis": "",
                        "risk_analysis": "",
                        "final_decision": ""
                    }
                    
                    result = swarm_graph.invoke(initial_state)
                    
                    # Display the CEO's final decision with research context
                    console.print(Panel.fit(
                        f"[bold white]{result['final_decision']}[/bold white]\n\n"
                        f"[dim]Research Intel: {result['research_context']}[/dim]",
                        title=f"[bold green]🎯 ECHELON SWARM DECISION - {ticker}[/bold green]",
                        border_style="green"
                    ))
                    
                    # Show intermediate analyses in dimmed text
                    console.print(f"[dim]Quant: {result['quant_analysis'][:80]}...[/dim]")
                    console.print(f"[dim]Risk: {result['risk_analysis'][:80]}...[/dim]")
                else:
                    console.print("[dim][NORMAL] Skipping AI analysis.[/dim]")
                
            except json.JSONDecodeError as e:
                console.print(f"[red]Failed to parse message: {e}[/red]")
                
    except KeyboardInterrupt:
        console.print("\n[yellow]Shutting down swarm...[/yellow]")
    finally:
        consumer.close()
        console.print("[cyan]Swarm stopped.[/cyan]")

if __name__ == "__main__":
    main()
