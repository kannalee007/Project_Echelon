#!/usr/bin/env python3
"""
Project Echelon - Data Streamer (Producer)
Generates simulated high-frequency market data for the AI Hedge Fund swarm.
"""

import json
import random
import time
from datetime import datetime, timezone
from confluent_kafka import Producer
from rich.console import Console
from rich.panel import Panel

console = Console()

# Configuration
BROKER = "localhost:19092"
TOPIC = "market_live_feed"
TICKERS = ["AAPL", "NVDA", "TSLA", "MSFT", "GOOGL", "AMZN", "META", "BTC-USD", "ETH-USD"]

def delivery_callback(err, msg):
    if err:
        console.print(f"[red]Delivery failed: {err}[/red]")
    else:
        console.print(f"[dim]Sent to {msg.topic()} partition {msg.partition()}[/dim]")

def generate_tick():
    ticker = random.choice(TICKERS)
    base_price = random.uniform(50, 500)
    tick = {
        "ticker": ticker,
        "current_price": round(base_price, 2),
        "volume": random.randint(1000, 1000000),
        "volatility_index": round(random.uniform(0.1, 5.0), 2),
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    }
    return tick

def main():
    conf = {
        "bootstrap.servers": BROKER,
        "client.id": "echelon-data-streamer"
    }
    producer = Producer(conf)
    
    console.print(Panel.fit(
        "[bold green]Project Echelon - Data Streamer[/bold green]\n"
        f"Broker: {BROKER}\n"
        f"Topic: {TOPIC}",
        title="Initializing",
        border_style="green"
    ))
    
    try:
        while True:
            tick = generate_tick()
            json_payload = json.dumps(tick)
            
            producer.produce(
                TOPIC,
                key=tick["ticker"].encode("utf-8"),
                value=json_payload.encode("utf-8"),
                callback=delivery_callback
            )
            producer.poll(0)
            
            console.print(
                f"[bold green][PRODUCER][/bold green] "
                f"{tick['ticker']} ${tick['current_price']} "
                f"Vol: {tick['volume']} "
                f"VIX: {tick['volatility_index']}"
            )
            
            time.sleep(1)
            
    except KeyboardInterrupt:
        console.print("\n[yellow]Shutting down streamer...[/yellow]")
    finally:
        producer.flush()
        console.print("[green]Streamer stopped.[/green]")

if __name__ == "__main__":
    main()
